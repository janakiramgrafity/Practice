package com.spring.Mservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MservicesApplication.class, args);
	}

}
